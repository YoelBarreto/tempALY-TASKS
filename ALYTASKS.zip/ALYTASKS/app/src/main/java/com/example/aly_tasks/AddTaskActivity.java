package com.example.aly_tasks;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class AddTaskActivity extends AppCompatActivity {

    private EditText editTaskName;
    private EditText editTaskNote;
    private Spinner spinnerPriority;
    private MaterialButton btnAddTask;
    private MaterialButton btnCancel;
    private TaskManager taskManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Asegúrate de que este layout coincida con el archivo de añadir tarea
        setContentView(R.layout.activity_add_task_view);

        // Inicializar TaskManager
        taskManager = TaskManager.getInstance();

        // 1. Enlazar vistas del layout
        editTaskName = findViewById(R.id.editTaskName); // Asegúrate de que el ID es correcto
        editTaskNote = findViewById(R.id.editTaskNote); // Asegúrate de que el ID es correcto
        spinnerPriority = findViewById(R.id.spinnerPriority); // Asegúrate de que el ID es correcto
        btnAddTask = findViewById(R.id.btnAddTask); // Asume un ID para el botón de añadir tarea
        btnCancel = findViewById(R.id.btnCancel); // Asume un ID para el botón de cancelar

        // 2. Configurar el Spinner de Prioridad
        setupSpinner();

        // 3. Configurar listeners de botones
        btnAddTask.setOnClickListener(v -> addTask());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void setupSpinner() {
        // Asegúrate de que R.array.priority_levels existe en strings.xml
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.priority_levels,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPriority.setAdapter(adapter);
    }

    private void addTask() {
        String name = editTaskName.getText().toString().trim();
        String note = editTaskNote.getText().toString().trim();
        // Obtiene el valor de la prioridad seleccionada (ej: "Alta", "Media", "Baja")
        String priority = spinnerPriority.getSelectedItem().toString();

        if (name.isEmpty()) {
            Toast.makeText(this, "El nombre de la tarea no puede estar vacío.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear una nueva instancia de Tarea usando el constructor simple (String, String, String)
        Tarea newTask = new Tarea(name, note, priority);

        // Llamar al TaskManager para que asigne el ID y la agregue a las listas
        taskManager.addTask(newTask);

        Toast.makeText(this, "Tarea '" + name + "' añadida.", Toast.LENGTH_SHORT).show();
        finish(); // Cierra la activity y regresa a MainActivity
    }
}