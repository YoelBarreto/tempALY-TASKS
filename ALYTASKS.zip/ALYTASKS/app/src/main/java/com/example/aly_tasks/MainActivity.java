// Archivo: MainActivity.java
package com.example.aly_tasks;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TaskManager.TaskListChangeListener {

    private TaskManager taskManager;
    private TareaAdapter pendingTasksAdapter;
    private TareaAdapter completedTasksAdapter;

    private ListView listViewPending;
    private MaterialButton removeTasksButton;
    private MaterialButton modifyTasksButton;
    private MaterialButton addTasksButton;
    private MaterialButton removeCompletedButton;
    private List<Tarea> selectedTasks;

    private ActivityResultLauncher<Intent> modificarTareaLauncher;
    private Tarea tareaModificando; // Referencia a la tarea que se está editando


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        taskManager = TaskManager.getInstance(this);
        selectedTasks = new ArrayList<>();

        listViewPending = findViewById(R.id.listView2);
        ListView listViewCompleted = findViewById(R.id.listView);
        removeTasksButton = findViewById(R.id.removeTasksButton);
        modifyTasksButton = findViewById(R.id.completeTasksButton); // Botón de MODIFICAR TAREA
        addTasksButton = findViewById(R.id.button3);
        removeCompletedButton = findViewById(R.id.completeTasksButton2);

        // Pasamos la lista de tareas seleccionadas al adaptador.
        pendingTasksAdapter = new TareaAdapter(this, taskManager.getPendingTasks(), selectedTasks);
        completedTasksAdapter = new TareaAdapter(this, taskManager.getCompletedTasks()); // Las completadas no son seleccionables

        listViewPending.setAdapter(pendingTasksAdapter);
        listViewCompleted.setAdapter(completedTasksAdapter);

        taskManager.setListener(this);

        setupPendingListSelection();
        setupRemoveButtonListener();
        setupAddButtonListener();
        setupModifyTaskLauncher();
        setupModifyButtonListener();
        setupRemoveCompletedButtonListener();

        updateTaskLists();
        updateButtonStates(); // Renombrado para mayor claridad
    }

    private void setupModifyTaskLauncher() {
        modificarTareaLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.hasExtra(ModificarTareaActivity.EXTRA_TAREA_MODIFICADA)) {
                            Tarea tareaModificada = (Tarea) data.getSerializableExtra(ModificarTareaActivity.EXTRA_TAREA_MODIFICADA);

                            if (tareaModificando != null && tareaModificada != null) {
                                taskManager.updateTask(tareaModificando, tareaModificada);
                                limpiarSeleccion(); // Limpia la selección después de una modificación exitosa
                                Toast.makeText(this, "Tarea '" + tareaModificada.getNombre() + "' modificada.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                    tareaModificando = null; // Limpiamos la referencia en cualquier caso
                }
        );
    }

    @Override
    public void onTaskListChanged() {
        // Actualizamos los adaptadores con las nuevas listas de tareas desde el TaskManager
        pendingTasksAdapter.clear();
        pendingTasksAdapter.addAll(taskManager.getPendingTasks());
        pendingTasksAdapter.notifyDataSetChanged();

        completedTasksAdapter.clear();
        completedTasksAdapter.addAll(taskManager.getCompletedTasks());
        completedTasksAdapter.notifyDataSetChanged();

        updateButtonStates();
    }

    private void updateTaskLists() {
        pendingTasksAdapter.notifyDataSetChanged();
        completedTasksAdapter.notifyDataSetChanged();
    }

    private void limpiarSeleccion() {
        selectedTasks.clear();
        updateButtonStates();
        // Notificamos al adaptador que la selección ha cambiado para que redibuje las vistas
        pendingTasksAdapter.notifyDataSetChanged();
    }

    private void updateButtonStates() {
        int count = selectedTasks.size();
        removeTasksButton.setText("ELIMINAR TAREAS SELECCIONADAS" + (count > 0 ? " (" + count + ")" : ""));

        // Lógica para el botón de modificar
        modifyTasksButton.setText("MODIFICAR TAREA"); // Texto fijo

        if (count == 1) {
            modifyTasksButton.setEnabled(true);
            modifyTasksButton.setBackgroundColor(ContextCompat.getColor(this, R.color.button_original));
        } else {
            modifyTasksButton.setEnabled(false);
            modifyTasksButton.setBackgroundColor(ContextCompat.getColor(this, R.color.button_disabled));
        }
    }

    private void setupPendingListSelection() {
        listViewPending.setOnItemClickListener((parent, view, position, id) -> {
            Tarea tarea = pendingTasksAdapter.getItem(position);
            if (tarea == null) return;

            if (selectedTasks.contains(tarea)) {
                selectedTasks.remove(tarea); // Deseleccionar
            } else {
                selectedTasks.add(tarea); // Seleccionar
            }

            // Notificar al adaptador que los datos (la selección) han cambiado
            pendingTasksAdapter.notifyDataSetChanged();
            updateButtonStates();
        });
    }

    private void setupRemoveButtonListener() {
        removeTasksButton.setOnClickListener(v -> {
            if (!selectedTasks.isEmpty()) {
                taskManager.removeSelectedTasks(new ArrayList<>(selectedTasks));
                limpiarSeleccion(); // Limpiamos la selección después de eliminar
                Toast.makeText(this, "Tareas eliminadas.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Selecciona al menos una tarea.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupModifyButtonListener() {
        modifyTasksButton.setOnClickListener(v -> {
            if (selectedTasks.size() == 1) {
                tareaModificando = selectedTasks.get(0);
                Intent intent = new Intent(MainActivity.this, ModificarTareaActivity.class);
                intent.putExtra("tareaSeleccionada", tareaModificando);
                modificarTareaLauncher.launch(intent);
            } else if (selectedTasks.isEmpty()) {
                Toast.makeText(this, "Selecciona la tarea a modificar.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Solo puedes modificar una tarea a la vez.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupAddButtonListener() {
        if (addTasksButton != null) {
            addTasksButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("MainActivity", "El botón '+' (button3) no fue encontrado en el layout.");
        }
    }

    private void setupRemoveCompletedButtonListener() {
        removeCompletedButton.setOnClickListener(v -> {
            List<Tarea> completedTasks = taskManager.getCompletedTasks();
            if (!completedTasks.isEmpty()) {
                taskManager.removeSelectedTasks(new ArrayList<>(completedTasks));
                Toast.makeText(this, "Tareas completadas eliminadas.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No hay tareas completadas para eliminar.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}