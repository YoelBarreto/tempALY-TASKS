// Archivo: ModificarTareaActivity.java
package com.example.aly_tasks;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.util.Arrays;

public class ModificarTareaActivity extends AppCompatActivity {

    public static final String EXTRA_TAREA_MODIFICADA = "tareaModificada";

    private Tarea tareaOriginal;
    private EditText editTaskName;
    private EditText editTaskNote;
    private Spinner spinnerPriority;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Usamos el layout que proporcionaste
        setContentView(R.layout.activity_modify_task_view);

        // 1. Enlazar vistas
        editTaskName = findViewById(R.id.editTaskName);
        editTaskNote = findViewById(R.id.editTaskNote);
        spinnerPriority = findViewById(R.id.spinnerPriority);
        MaterialButton btnSave = findViewById(R.id.btnSaveModifications);
        MaterialButton btnCancel = findViewById(R.id.btnCancel);

        // 2. Obtener la tarea a modificar del Intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("tareaSeleccionada")) {
            // La clave "tareaSeleccionada" es la que usamos en MainActivity
            tareaOriginal = (Tarea) intent.getSerializableExtra("tareaSeleccionada");
        }

        if (tareaOriginal == null) {
            Toast.makeText(this, "Error: No se encontró la tarea para modificar.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // 3. Cargar detalles y configurar Spinner
        loadTaskDetails();
        setupSpinner();

        // 4. Manejar el botón Guardar Cambios
        btnSave.setOnClickListener(v -> saveModificationsAndReturn());

        // 5. Manejar el botón Cancelar
        btnCancel.setOnClickListener(v -> {
            setResult(Activity.RESULT_CANCELED); // Indica que no hubo cambios
            finish();
        });
    }

    private void setupSpinner() {
        // Asegúrate de tener R.array.priority_levels en tu archivo strings.xml
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.priority_levels,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPriority.setAdapter(adapter);
    }

    private void loadTaskDetails() {
        editTaskName.setText(tareaOriginal.getNombre());
        editTaskNote.setText(tareaOriginal.getNota());

        // Configurar la prioridad actual
        String priority = tareaOriginal.getPrioridad();
        String[] priorityArray = getResources().getStringArray(R.array.priority_levels);
        int spinnerPosition = Arrays.asList(priorityArray).indexOf(priority);
        if (spinnerPosition >= 0) {
            spinnerPriority.setSelection(spinnerPosition);
        }
    }

    private void saveModificationsAndReturn() {
        String newName = editTaskName.getText().toString().trim();
        String newNote = editTaskNote.getText().toString().trim();
        String newPriority = spinnerPriority.getSelectedItem().toString();

        if (newName.isEmpty()) {
            Toast.makeText(this, "El nombre de la tarea no puede estar vacío.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Creamos un nuevo objeto Tarea que contiene los datos modificados.
        // Mantenemos el mismo ID y estado de completado (isCompletada()) de la original.
        Tarea tareaModificada = new Tarea(
                tareaOriginal.getId(),
                newName,
                newNote,
                newPriority,
                tareaOriginal.isCompletada()
        );

        // Devolver el resultado a MainActivity
        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_TAREA_MODIFICADA, tareaModificada);

        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
}