package com.example.aly_tasks;

import java.io.Serializable;

public class Tarea implements Serializable {

    private int id; // Identificador único de la tarea
    private String nombre;
    private String nota;
    private String prioridad;
    private boolean completada;

    // CONSTRUCTOR 1: Para crear nuevas tareas desde AddTaskActivity (NUEVO)
    public Tarea(String nombre, String nota, String prioridad) {
        // ID y completada se inicializarán más tarde o se gestionan en TaskManager
        this.nombre = nombre;
        this.nota = nota;
        this.prioridad = prioridad;
        this.completada = false;
    }

    // CONSTRUCTOR 2: Para reconstruir tareas desde la DB o pasar datos completos (EXISTENTE)
    public Tarea(int id, String nombre, String nota, String prioridad, boolean completada) {
        this.id = id;
        this.nombre = nombre;
        this.nota = nota;
        this.prioridad = prioridad;
        this.completada = completada;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNota() {
        return nota;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public boolean isCompletada() {
        return completada;
    }

    // Setters (Necesarios para la modificación)
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }
}