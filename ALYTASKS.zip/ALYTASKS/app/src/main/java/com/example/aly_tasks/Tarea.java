package com.example.aly_tasks;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "tareas")
public class Tarea implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nombre;
    private String nota;
    private String prioridad;
    private boolean completada;

    // CONSTRUCTOR para Room y reconstrucción de objetos
    public Tarea(int id, String nombre, String nota, String prioridad, boolean completada) {
        this.id = id;
        this.nombre = nombre;
        this.nota = nota;
        this.prioridad = prioridad;
        this.completada = completada;
    }

    @Ignore
    // CONSTRUCTOR: Para crear nuevas tareas desde AddTaskActivity
    public Tarea(String nombre, String nota, String prioridad) {
        this.nombre = nombre;
        this.nota = nota;
        this.prioridad = prioridad;
        this.completada = false;
    }
    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNota() {
        return nota;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public boolean isCompletada() {
        return completada;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }
}