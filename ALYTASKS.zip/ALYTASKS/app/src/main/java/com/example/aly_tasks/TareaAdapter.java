package com.example.aly_tasks;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color; // Import for Color.TRANSPARENT
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat; // Import for compatibility

import java.util.List;

public class TareaAdapter extends ArrayAdapter<Tarea> {

    private final Context context;
    private final List<Tarea> selectedTasks; // Lista para saber qué elementos están seleccionados

    // Constructor principal que acepta la lista de selección
    public TareaAdapter(Context context, List<Tarea> tareas, List<Tarea> selectedTasks) {
        super(context, 0, tareas);
        this.context = context;
        this.selectedTasks = selectedTasks;
    }

    // Constructor secundario para listas que no necesitan selección (como las tareas completadas)
    public TareaAdapter(Context context, List<Tarea> tareas) {
        // Llama al constructor principal sin lista de selección
        this(context, tareas, null);
    }

    private static class ViewHolder {
        TextView txtNombre;
        CheckBox chkCompletada;
        ImageView star1;
        ImageView star2;
        ImageView star3;
        Button btnVerNotas;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Tarea tarea = getItem(position);
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_tarea, parent, false);
            holder = new ViewHolder();
            holder.txtNombre = convertView.findViewById(R.id.txtNombre);
            holder.chkCompletada = convertView.findViewById(R.id.chkCompletada);
            holder.star1 = convertView.findViewById(R.id.star1);
            holder.star2 = convertView.findViewById(R.id.star2);
            holder.star3 = convertView.findViewById(R.id.star3);
            holder.btnVerNotas = convertView.findViewById(R.id.btnVerNotas);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.chkCompletada.setOnCheckedChangeListener(null);

        holder.txtNombre.setText(tarea.getNombre());
        holder.chkCompletada.setChecked(tarea.isCompletada());

        int prioridadLevel = getPriorityLevel(tarea.getPrioridad());
        holder.star1.setVisibility(prioridadLevel >= 1 ? View.VISIBLE : View.GONE);
        holder.star2.setVisibility(prioridadLevel >= 2 ? View.VISIBLE : View.GONE);
        holder.star3.setVisibility(prioridadLevel == 3 ? View.VISIBLE : View.GONE);

        final String nota = tarea.getNota();
        if (nota != null && !nota.trim().isEmpty()) {
            holder.btnVerNotas.setVisibility(View.VISIBLE);
            holder.btnVerNotas.setOnClickListener(v -> {
                new AlertDialog.Builder(context)
                        .setTitle("Notas de: " + tarea.getNombre())
                        .setMessage(nota)
                        .setPositiveButton("Cerrar", (dialog, id) -> dialog.dismiss())
                        .show();
            });
        } else {
            holder.btnVerNotas.setVisibility(View.GONE);
            holder.btnVerNotas.setOnClickListener(null);
        }

        holder.chkCompletada.setOnCheckedChangeListener((buttonView, isChecked) -> {
            TaskManager.getInstance(context).toggleTaskCompletion(tarea);
        });

        // --- LÓGICA DE SELECCIÓN VISUAL ---
        // Si la lista de seleccionados existe y contiene esta tarea, la destacamos.
        if (selectedTasks != null && selectedTasks.contains(tarea)) {
            // Es buena práctica usar un color de tus recursos (ej: R.color.selection_color)
            // Asumimos que R.color.azul_claro está definido en tus colores.
            int selectionColor = ContextCompat.getColor(context, R.color.azul_claro);
            convertView.setBackgroundColor(selectionColor);
        } else {
            // Si no está seleccionada, el fondo es transparente.
            convertView.setBackgroundColor(Color.TRANSPARENT);
        }

        return convertView;
    }

    private int getPriorityLevel(String prioridad) {
        if (prioridad == null) return 0;
        String[] priorityArray = context.getResources().getStringArray(R.array.priority_levels);
        for (int i = 0; i < priorityArray.length; i++) {
            if (prioridad.equals(priorityArray[i])) {
                return i + 1;
            }
        }
        return 0;
    }
}
