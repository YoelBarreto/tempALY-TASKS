package com.example.aly_tasks;

import java.util.ArrayList;
import java.util.List;

public class TaskManager {

    // --- Singleton Pattern ---
    private static TaskManager instance;
    private TaskListChangeListener listener;

    private final List<Tarea> allTasks = new ArrayList<>();
    private final List<Tarea> pendingTasks = new ArrayList<>();
    private final List<Tarea> completedTasks = new ArrayList<>();

    private int nextTaskId = 1;

    private TaskManager() {
        // Constructor privado
    }

    public static TaskManager getInstance() {
        if (instance == null) {
            instance = new TaskManager();
        }
        return instance;
    }
    // -------------------------

    public interface TaskListChangeListener {
        void onTaskListChanged();
    }

    public void setListener(TaskListChangeListener listener) {
        this.listener = listener;
    }

    private void notifyListeners() {
        if (listener != null) {
            listener.onTaskListChanged();
        }
    }

    // --- Getters de Listas ---

    public List<Tarea> getPendingTasks() {
        return pendingTasks;
    }

    public List<Tarea> getCompletedTasks() {
        return completedTasks;
    }

    // --- Lógica de Tareas ---

    public void addTask(Tarea nuevaTarea) {
        nuevaTarea.setId(nextTaskId++);
        nuevaTarea.setCompletada(false);

        allTasks.add(nuevaTarea);
        pendingTasks.add(nuevaTarea);
        notifyListeners();
    }

    public void removeSelectedTasks(List<Tarea> tasksToRemove) {
        allTasks.removeAll(tasksToRemove);
        pendingTasks.removeAll(tasksToRemove);
        completedTasks.removeAll(tasksToRemove);
        notifyListeners();
    }

    public void toggleTaskCompletion(Tarea tarea) {
        Tarea target = getTaskById(tarea.getId());
        if (target != null) {
            boolean newState = !target.isCompletada();
            target.setCompletada(newState);

            if (newState) {
                pendingTasks.remove(target);
                completedTasks.add(target);
            } else {
                completedTasks.remove(target);
                pendingTasks.add(target);
            }
            notifyListeners();
        }
    }

    public Tarea getTaskById(int taskId) {
        for (Tarea tarea : allTasks) {
            if (tarea.getId() == taskId) {
                return tarea;
            }
        }
        return null;
    }


    public void updateTask(Tarea original, Tarea modified) {
        if (original == null || modified == null) {
            return;
        }

        // Como la modificación solo está disponible para tareas pendientes, solo buscamos en esa lista.
        int taskIndexInPending = -1;
        for (int i = 0; i < pendingTasks.size(); i++) {
            if (pendingTasks.get(i).getId() == original.getId()) {
                taskIndexInPending = i;
                break;
            }
        }

        // Si se encuentra en la lista de pendientes, la reemplazamos.
        if (taskIndexInPending != -1) {
            pendingTasks.set(taskIndexInPending, modified);
        }

        // También actualizamos la lista principal que contiene todas las tareas.
        int taskIndexInAll = -1;
        for (int i = 0; i < allTasks.size(); i++) {
            if (allTasks.get(i).getId() == original.getId()) {
                taskIndexInAll = i;
                break;
            }
        }

        if (taskIndexInAll != -1) {
            allTasks.set(taskIndexInAll, modified);
        }

        // Notificamos a la UI para que se refresque con los cambios.
        notifyListeners();
    }
}
