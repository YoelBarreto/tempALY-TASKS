package com.example.aly_tasks;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TaskManager {

    // --- Singleton Pattern ---
    private static TaskManager instance;
    private TaskListChangeListener listener;
    private TareaDao tareaDao;

    private TaskManager(Context context) {
        AppDatabase db = AppDatabase.getDatabase(context);
        this.tareaDao = db.tareaDao();
    }

    public static TaskManager getInstance(Context context) {
        if (instance == null) {
            instance = new TaskManager(context.getApplicationContext());
        }
        return instance;
    }
    // -------------------------

    public interface TaskListChangeListener {
        void onTaskListChanged();
    }

    public void setListener(TaskListChangeListener listener) {
        this.listener = listener;
    }

    private void notifyListeners() {
        if (listener != null) {
            listener.onTaskListChanged();
        }
    }

    // --- Getters de Listas (ahora desde la DB) ---

    public List<Tarea> getPendingTasks() {
        return tareaDao.getAll().stream().filter(t -> !t.isCompletada()).collect(Collectors.toList());
    }

    public List<Tarea> getCompletedTasks() {
        return tareaDao.getAll().stream().filter(Tarea::isCompletada).collect(Collectors.toList());
    }

    // --- Lógica de Tareas (ahora con DB) ---

    public void addTask(Tarea nuevaTarea) {
        tareaDao.insert(nuevaTarea);
        notifyListeners();
    }

    public void removeSelectedTasks(List<Tarea> tasksToRemove) {
        for(Tarea tarea : tasksToRemove) {
            tareaDao.delete(tarea);
        }
        notifyListeners();
    }

    public void toggleTaskCompletion(Tarea tarea) {
        tarea.setCompletada(!tarea.isCompletada());
        tareaDao.update(tarea);
        notifyListeners();
    }

    public Tarea getTaskById(int taskId) {
        // Esta implementación es menos eficiente. Si se necesita a menudo, crear un método en el DAO.
        return tareaDao.getAll().stream().filter(t -> t.getId() == taskId).findFirst().orElse(null);
    }

    public void updateTask(Tarea original, Tarea modified) {
        // El ID no debe cambiar. Asignamos el ID original al modificado.
        modified.setId(original.getId());
        tareaDao.update(modified);
        notifyListeners();
    }
}